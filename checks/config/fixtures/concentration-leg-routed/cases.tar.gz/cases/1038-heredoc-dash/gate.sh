set -e
cat <<-EOF >/dev/null
run "concentration"  npm run --silent gate:concentration
EOF
