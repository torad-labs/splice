set -e
disabled() {
  run "concentration"  npm run --silent gate:concentration
}
