set -e
run "concentration" npm run --prefix /tmp --if-present gate:concentration
