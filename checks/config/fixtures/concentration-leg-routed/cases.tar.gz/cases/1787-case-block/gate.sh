set -e
case x in
  x)
    run "concentration"  npm run --silent gate:concentration
    ;;
esac
