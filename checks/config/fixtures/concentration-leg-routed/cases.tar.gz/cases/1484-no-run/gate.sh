set -e
npm run --silent gate:concentration
