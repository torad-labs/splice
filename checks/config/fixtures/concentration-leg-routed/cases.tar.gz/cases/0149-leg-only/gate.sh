set -e
run "concentration"  npm run --silent gate:concentration
