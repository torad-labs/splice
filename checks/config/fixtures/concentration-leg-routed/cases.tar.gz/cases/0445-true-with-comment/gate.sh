set -e
run "concentration"  true  # gate:concentration disabled
