set -e
echo 'oops
run "concentration"  npm run --silent gate:concentration
