set -e
awk '{print $1}' /dev/null
run "concentration"  npm run --silent gate:concentration
