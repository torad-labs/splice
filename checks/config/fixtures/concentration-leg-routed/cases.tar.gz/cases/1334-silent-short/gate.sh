set -e
run "concentration" npm run -s gate:concentration
