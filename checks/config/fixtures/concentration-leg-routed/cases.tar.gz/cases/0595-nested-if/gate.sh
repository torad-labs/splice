set -e
if false; then
  run "concentration"  npm run --silent gate:concentration
fi
