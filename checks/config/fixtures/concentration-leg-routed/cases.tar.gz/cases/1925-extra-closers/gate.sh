set -e
fi
done
run "concentration"  npm run --silent gate:concentration
